<?php

error_reporting(E_ALL);
ini_set("display_errors", 1);

//se usa para enviar una cabecera HTTP a palo seco
//normalmente se redirige con location pero tambien se usa para indicar el tipo de dato contenido
header("Content-Type: application/json");
require "conexionPDO.php";

$metodo = $_SERVER["REQUEST_METHOD"];
//lee el cuerpo de la solicitud
$entrada = file_get_contents("php://input");

//de json a array asociativo
$entrada = json_decode($entrada, true);



try {
    $consulta = "SELECT nombre FROM jugadores";
    $stmt = $_conexion->prepare($consulta);
    $stmt->execute();
    $fila = $stmt->fetchAll(PDO::FETCH_ASSOC);
    // json_encode($fila);
    echo json_encode($fila); // HE ENCONTRADO QUE SE PUEDE UTILIZAR "JSON_UNESCAPED_UNICODE" para evitar secuencias raras a la hora de mostrar el JSON.
    // echo json_encode($fila, JSON_UNESCAPED_UNICODE);

} catch (PDOException $e) {
    echo "Error en la consulta " . $e->getMessage();
}

